package livingbeings.animal;

interface Fight
{
	void fight();
}
interface Death
{
	void  die();
}
public class Animal implements Fight, Death{

	public void eating(Fight f)
	{
		System.out.println("Eating_____");
		f.fight();
	}
	public void sleep(Death d)
	{
		System.out.println("Sleeping______");
		d.die();
	}
	public void reproduce()
	{
		System.out.println("Reproducing______");
	}
	@Override
	public void fight() {
		System.out.println("Animal Fight also");
		
	}
	@Override
	public void die() {
		System.out.println("Animal dies after fight");
		
	}
	
}
