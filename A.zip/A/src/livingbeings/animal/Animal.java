package livingbeings.animal;

public class Animal {

	public void eating()
	{
		System.out.println("Eating_____");
	}
	public void sleep()
	{
		System.out.println("Sleeping______");
	}
	public void reproduce()
	{
		System.out.println("Reproducing______");
	}
	
}
