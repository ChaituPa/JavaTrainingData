package livingbeings.animal.mammal;

import livingbeings.animal.Animal;

public class Mammal extends Animal
{

	public void giveBirth()
	{
		System.out.println("Mammals give birth");
	}
}
