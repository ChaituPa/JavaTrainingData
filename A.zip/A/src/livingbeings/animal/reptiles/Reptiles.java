package livingbeings.animal.reptiles;

import livingbeings.animal.Animal;

interface Scales
{
	void scales();
}

public class Reptiles extends Animal implements Scales
{
public void layEggs(Scales s)
{
	System.out.println("Reptiles lay eggs");
	s.scales();
}

@Override
public void scales() {
System.out.println("Reptiles also have scales");	
}
}
