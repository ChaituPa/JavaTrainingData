package livingbeings.animal.reptiles;

import livingbeings.animal.Animal;

interface Scales
{
	void scales();
}

public class Reptiles extends Animal implements Scales
{
public void layEggs()
{
	System.out.println("Reptiles lay eggs");
}

@Override
public void scales() {
System.out.println("Reptiles have scales");	
}
}
