package livingbeings.director;

import livingbeings.human.*;
import livingbeings.manager.Manager;

public class Director extends Manager {
 public void direct()
 {
	 System.out.println("Directing");
 }
}
