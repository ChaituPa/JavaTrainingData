package livingbeings.executive;

import livingbeings.student.Student;
import livingbeings.human.*;

public class Executive extends Student
{
	public void execute()
	{
		System.out.println("Executing__");
	}

}
