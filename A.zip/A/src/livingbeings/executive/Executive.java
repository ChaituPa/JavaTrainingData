package livingbeings.executive;

import livingbeings.student.Student;

interface Plan
{
	void planning();
}

public class Executive extends Student implements Plan
{
	public void execute(Plan p)
	{
		p.planning();
	}

	@Override
	public void planning() {
		// TODO Auto-generated method stub
		System.out.println("Executive is planning now for new business.. anf implementation");
	}

}
