package livingbeings.founder;

import livingbeings.director.Director;

public class Founder extends Director {

	public void found()
	{
		System.out.println("Found");
	}
}
