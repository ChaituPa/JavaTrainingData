package livingbeings.human;

import livingbeings.animal.mammal.Mammal;

interface Imagine
{
	void imagine();
	
}


public class Human extends Mammal implements Imagine
{
public void thinking(Imagine i)
{
		System.out.println("Capable of thinking");
	
		i.imagine();
		
}

@Override
public void imagine() {
System.out.println("Imagination");	
}
}

