package livingbeings.manager;

import livingbeings.executive.Executive;

public class Manager extends Executive{
public void manage()
{
	System.out.println("Managing");
}
}
