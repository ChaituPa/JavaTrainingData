package livingbeings.person;

import livingbeings.human.Human;

interface Walk
{
	void walking();
}

public class Person extends Human implements Walk
{
public void beingActive()
{
	System.out.println("person is being active");
}

@Override
public void walking() {
	// TODO Auto-generated method stub
	System.out.println("Walking...");
}
}

