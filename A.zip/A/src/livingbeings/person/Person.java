package livingbeings.person;

import livingbeings.human.Human;

interface Walk
{
	void walking();
}

public class Person extends Human implements Walk
{
public void beingActive(Walk w)
{
	System.out.println("person is being active");
	w.walking();
}

@Override
public void walking() {
	// TODO Auto-generated method stub
	System.out.println("Person walking means you are active...");
}
}

