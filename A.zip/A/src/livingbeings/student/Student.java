package livingbeings.student;

import livingbeings.person.Person;


interface Learn
{
	void learn();
}

interface Dance
{
	void dance();
}

public class Student extends Person implements Learn, Dance
{
public void studying()
{System.out.println("student is studying for the exams");
}

@Override
public void learn() {
	System.out.println("Learning is FUN");
	
}

@Override
public void dance() {
	System.out.println("Dancing is FUNNN");
}
}
