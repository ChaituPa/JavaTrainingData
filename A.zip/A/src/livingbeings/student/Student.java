package livingbeings.student;

import livingbeings.person.Person;


interface Learn
{
	void learn();
}

interface Dance
{
	void dance();
}

public class Student extends Person implements Learn, Dance
{
public void studying(Learn l, Dance d)
{//System.out.println("student is studying for the exams");
l.learn();
d.dance();
}

@Override
public void learn() {
	System.out.println("Student-> Learning is FUN");
	
}

@Override
public void dance() {
	System.out.println("A Student Dancing is FUNNN");
}
}
