package livingbeings.usage;

import java.util.MissingFormatArgumentException;

import livingbeings.animal.Animal;
import livingbeings.animal.mammal.Mammal;
import livingbeings.animal.reptiles.Reptiles;
import livingbeings.director.Director;
import livingbeings.executive.Executive;
import livingbeings.founder.Founder;
import livingbeings.human.Human;
import livingbeings.manager.Manager;
import livingbeings.person.Person;
import livingbeings.student.Student;

public class Usage {

	public static void main(String[] args) {
		System.out.println("Welcome to the Java Programming World.... We are learning about the Packages, Association and Interfaces");
		Animal a= new Animal();
		a.eating(a); a.sleep(a);
		
		Mammal m= new Mammal();
		m.giveBirth(); 	
		
		Reptiles r= new Reptiles();
		r.layEggs(r);  
	
		Director d= new Director();
		d.direct(); d.eating(a);
		
		Executive e= new Executive();
		e.execute(e); e.beingActive(e);
		
		Human h= new Human();
		 h.thinking(h); 
		
		Person p= new Person();
		p.beingActive(p); 
		
		Student s= new Student();
		s.learn(); s.studying(s,s);
		
		Manager man = new Manager();
		man.manage();
		
		Founder f= new Founder();
		f.found(); f.learn(); 
				
		
		
	}
}

