package com.sbi.admin.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.admin.controller.MailController;
import com.sbi.admin.entity.BankApplicant;
import com.sbi.admin.repository.BankApplicantRepository;



@Service
public class BankApplicantServiceImpl implements BankApplicantService {

	@Autowired
	BankApplicantRepository bankApplicantRepository;
	
	@Autowired
	MailService mailService;
	
	@Override
	public List<BankApplicant> fetchAllApplicantService() {
		
		List<BankApplicant> applList= bankApplicantRepository.getAllApplicant();
		return applList;
	}

	@Override
	public BankApplicant fetchApplicantByIdService(int id) 
	{	
		return bankApplicantRepository.getApplicantById(id);	
	}

	
	@Override
	public void modifyApplicantService(BankApplicant applicant) {
		
		bankApplicantRepository.updateApplicant(applicant);
		
		
	}
	
	
	
	

	@Override
	public BankApplicant fetchApplicantByStatusService(String status) {
		// TODO Auto-generated method stub
		return bankApplicantRepository.getApplicantByStatus(status);
		
	}

	@Override
	public void modifyApplicantStatusService(int appid ,String newStatusValue) 
	{
		
		BankApplicant bankApplicant = bankApplicantRepository.getApplicantById(appid);
		if(bankApplicant!=null) {
			bankApplicant.setApplicationStatus(newStatusValue);
			bankApplicantRepository.updateApplicant(bankApplicant);

			if(newStatusValue.equals("Approved")) {
				mailService.sendMail("Dear Sir, Your Application with Applicant Id"
			        +bankApplicant.getApplicantId()+" got "+newStatusValue+" for Account Opening. "
			        + "Thank You for Banking With Us!..", bankApplicant.getEmail());
				System.out.println("approval mail sent...");
			}
			else if(newStatusValue.equals("Rejected")) {
				mailService.sendMail("Dear Sir, Your Application with Applicant Id"+bankApplicant.getApplicantId()
				+" got "+newStatusValue+" due to KYC not matched. Please visit the Branch with ", bankApplicant.getEmail());
				System.out.println("Rejection mail sent...");
			}
		}
		else {
			throw new RuntimeException("Applicant not found");
		}
		
	}
	
	/*

	@Override
	public void addApplicantService(BankApplicant applicant) {
		
		bankApplicantRepository.insertApplicant(applicant);
		
	}

	
	@Override
	public void deleteApplicantByIdService(int id) {
		
		bankApplicantRepository.deleteBankApplicant(id);
		
	}
	*/
}
