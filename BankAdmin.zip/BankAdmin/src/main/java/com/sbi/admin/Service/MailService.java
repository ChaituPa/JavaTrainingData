package com.sbi.admin.Service;

public interface MailService {
	public void sendMail(String info, String email);
}
