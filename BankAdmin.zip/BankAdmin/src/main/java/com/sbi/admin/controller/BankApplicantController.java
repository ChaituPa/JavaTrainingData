package com.sbi.admin.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.sbi.admin.Service.BankApplicantService;
import com.sbi.admin.entity.BankApplicant;


@CrossOrigin
@RestController
@RequestMapping("/applicants")
public class BankApplicantController 
{	
	@Autowired
	BankApplicantService bankApplicantService;
	
	
	@RequestMapping("/")
	public List<BankApplicant> ViewAllApplicant()
	{ 
		//https://localhost:8080/applicants/
		System.out.println("BankApplicant  : ViewAllApplicant is invoked....");		
		return bankApplicantService.fetchAllApplicantService();
	}
	
	
	@RequestMapping("/{applId}")
	public BankApplicant ViewSingleApplicantById(@PathVariable("applId") int applicantNo)
	{ 	//https://localhost:8080/applicants/20220001
		System.out.println("BankApplicant  : ViewSingleApplicant is invoked....");
		BankApplicant bankApplicant = null;			
		bankApplicant = bankApplicantService.fetchApplicantByIdService(applicantNo);		
		return bankApplicant;
	}
	
//	@RequestMapping("/{status}")
//	public BankApplicant viewApplicantByStatus(@PathVariable("status") String status)
//	{ 	//https://localhost:8080/applicants/APPROVED
//		System.out.println("BankApplicant  : viewApplicantByStatus is invoked....");
//		BankApplicant bankApplicant = null;			
//		bankApplicant = bankApplicantService.fetchApplicantByStatusService(status);		
//		return bankApplicant;
//	}
		
	
	@PutMapping("/updateAppl/{status}")
	public String updateApplicant(@PathVariable("status") String status, @RequestBody BankApplicant applicantData)
	{ 	//https://localhost:8080/applicants/updateAppl
		
		System.out.println("Bank Applicant : updateApplicant is invoked....");
		bankApplicantService.modifyApplicantStatusService(applicantData.getApplicantId(),status);	
		return "Applicant Updated.......";
	}
	
	
}
