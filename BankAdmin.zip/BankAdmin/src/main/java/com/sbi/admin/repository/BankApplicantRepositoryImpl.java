package com.sbi.admin.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sbi.admin.entity.BankApplicant;


@Repository("BankApplicantRepo")
public class BankApplicantRepositoryImpl implements BankApplicantRepository {

	@PersistenceContext
	EntityManager  entityManager;
	
	@Override
	public List<BankApplicant> getAllApplicant() {
		System.out.println("Calling BankApplicantRepositoryImpl.getAllApplicant");		
		TypedQuery<BankApplicant >query = entityManager.createQuery("from BankApplicant", BankApplicant.class);
		System.out.println("List"+query);
		return query.getResultList();
	}
	
	@Override
	public BankApplicant getApplicantById(int id) {
		
		return entityManager.find(BankApplicant.class, id);
	}
	
	@Override
	public BankApplicant getApplicantByStatus(String status) {
		
		return entityManager.find(BankApplicant.class, status);
	}
	
	@Transactional
	public void updateApplicant(BankApplicant applicant) {
		
		entityManager.merge(applicant);
	}

	@Override
	public void updateApplicantStatus(BankApplicant applicant) {
	
		
		//entityManager.merge(applicant.setApplicationStatus(null));
	}
	
	/*
	@Transactional
	public void insertApplicant(BankApplicant applicant) {
		
		entityManager.persist(applicant);
	}
	
	@Transactional
	public void deleteBankApplicant(int id) {
		
		BankApplicant applicant = entityManager.find(BankApplicant.class, id);
		entityManager.remove(applicant);
	}
	*/
}
