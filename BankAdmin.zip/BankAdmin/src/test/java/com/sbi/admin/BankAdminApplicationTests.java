package com.sbi.admin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankAdminApplicationTests {

	@Test
	void contextLoads() {
	}

}
