package com.sbi.admin;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.sbi.admin.entity.BankApplicant;
import com.sbi.admin.repository.BankApplicantRepository;


@SpringBootTest
public class BankAdminRepositoryTest {
	
	@Autowired
	BankApplicantRepository bankApplicantRespository;
	
	@Test
	public void loadApplicants() 
	{
		
		List<BankApplicant> applicantList = bankApplicantRespository.getAllApplicant();
		
		for (BankApplicant bankApplicant : applicantList) 
		{
			System.out.println("load Applicant invoked in @Test");
			System.out.println("Applicant Id is: "+bankApplicant.getApplicantId());
			System.out.println("Applicant Name is : "+bankApplicant.getFirstName());
			System.out.println("Applicant Income is : "+bankApplicant.getAnnualIncome());			
		}
	}
}
