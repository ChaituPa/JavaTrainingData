package com.sbi.admin;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.sbi.admin.Service.BankApplicantService;
import com.sbi.admin.entity.BankApplicant;



@SpringBootTest
public class BankAdminServiceTest {


	@Autowired
	BankApplicantService bankApplicantService;	// ng g m myservices
												// ng g s myservices/customer -> customer.service.ts
		
	@Test
	public void loadApplicants() 
	{
		
		List<BankApplicant> applicantList = bankApplicantService.fetchAllApplicantService();
		
		for (BankApplicant bankApplicant : applicantList) 
		{
			System.out.println("load Applicant invoked in @Test");
			System.out.println("Applicant Id from service Test is: "+bankApplicant.getApplicantId());
			System.out.println("Applicant Name from service Test is : "+bankApplicant.getFirstName()+""+bankApplicant.getMiddleName()+""+bankApplicant.getLastName());
			System.out.println("Applicant Income  from Service Test is : "+bankApplicant.getAnnualIncome());			
		}
	}
	
	@Test
	public void modifyApplicantStatusServiceTest() {
		bankApplicantService.modifyApplicantStatusService(20220001, "Rejected");
	}
}
	

