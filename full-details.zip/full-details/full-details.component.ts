import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-full-details',
  templateUrl: './full-details.component.html',
  styleUrls: ['./full-details.component.css']
})
export class FullDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
