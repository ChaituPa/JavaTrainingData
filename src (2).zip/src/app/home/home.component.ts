import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApplicantDetailsService } from '../applicant-details.service';
import { HApplicantDetails } from './HApplicantDetails';



@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  // constructor(private router: Router) { }

  // ngOnInit(): void {
  // }
  // logout(){
  //   this.router.navigate(['/logout']);
  // }
  applicantList: HApplicantDetails[]=[];
  constructor(private ads: ApplicantDetailsService) { }
  
  ngOnInit(): void {
    this.ads.loadAllApplicantDetailsService().subscribe(
      (data) => {
        this.applicantList = data;
      },
      (err) => {
        console.log(err);
      }
  );
  }
 

}
