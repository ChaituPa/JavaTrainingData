import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApplicantDetailsService } from '../applicant-details.service';
import { ApplicantDetails } from '../applicant/ApplicantDetails';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  // constructor(private router: Router) { }

  // ngOnInit(): void {
  // }
  // logout(){
  //   this.router.navigate(['/logout']);
  // }
  
  applicantList: ApplicantDetails[]=[];

  constructor(private ads: ApplicantDetailsService) { }
  
  ngOnInit(): void {
    this.ads.loadAllApplicantDetailsService().subscribe(
      (data) => {
        this.applicantList = data;
        console.log(this.applicantList);
      },
      (err) => {
        console.log(err);
      }
  );
}
}