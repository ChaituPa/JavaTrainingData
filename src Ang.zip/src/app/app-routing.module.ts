import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ApplicantDetailsComponent } from './applicant-details/applicant-details.component';
import { ApprovedApplComponent } from './approved-appl/approved-appl.component';
import { FirstloginpageComponent } from './firstloginpage/firstloginpage.component';

import { LogoutComponent } from './logout/logout.component';
import { MainComponent } from './main/main.component';
import { NewHeaderComponent } from './new-header/new-header.component';
import { PendingApplComponent } from './pending-appl/pending-appl.component';
import { RejectedApplComponent } from './rejected-appl/rejected-appl.component';
import { TotalApplicantsComponent } from './total-applicants/total-applicants.component';

const routes: Routes = [
  {path:'', component:FirstloginpageComponent}, 
  {path:'header', component:NewHeaderComponent},
  {path:'main',
  children:[   
  {path:'', component:MainComponent},
  {path:'totalApplicants', component:TotalApplicantsComponent},
  {path:'app-details/:appid', component:ApplicantDetailsComponent},
  {path:'approved', component:ApprovedApplComponent},
  {path:'pending', component:PendingApplComponent},
  {path:'rejected', component:RejectedApplComponent},
  ]},
  {path:'login', component:FirstloginpageComponent},
  {path:'logout', component:LogoutComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
 