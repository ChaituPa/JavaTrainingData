import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ApprovedApplComponent } from './approved-appl.component';

describe('ApprovedApplComponent', () => {
  let component: ApprovedApplComponent;
  let fixture: ComponentFixture<ApprovedApplComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ApprovedApplComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ApprovedApplComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
