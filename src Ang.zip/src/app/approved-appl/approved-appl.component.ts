import { Component, OnInit } from '@angular/core';
import { ApplicantDetailsService } from '../applicant-details.service';
import { ApplicantDetails } from '../applicant/ApplicantDetails';

@Component({
  selector: 'app-approved-appl',
  templateUrl: './approved-appl.component.html',
  styleUrls: ['./approved-appl.component.css']
})
export class ApprovedApplComponent implements OnInit {

  applicantList: ApplicantDetails[]=[];
  applicantDetails: ApplicantDetails= new ApplicantDetails();
  constructor(private ads: ApplicantDetailsService) { }
  
  ngOnInit(): void { }
  x:string='Approved';

  loadByStatus(x : string) {
  this.ads.loadApplicantDetailByStatusService(x).subscribe({
    next:(data) => {
        this.applicantDetails = data;
      
        //console.log(this.message);
      },
      error:(err) => {
        console.log(err);
      }
    }
  );
}
}
