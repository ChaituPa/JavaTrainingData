import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RejectedApplComponent } from './rejected-appl.component';

describe('RejectedApplComponent', () => {
  let component: RejectedApplComponent;
  let fixture: ComponentFixture<RejectedApplComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RejectedApplComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RejectedApplComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
