import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ApplicantDetailsComponent } from './applicant-details/applicant-details.component';
import { HomeComponent } from './home/home.component';
import { LogoutComponent } from './logout/logout.component';
import { MainComponent } from './main/main.component';

const routes: Routes = [
  {path:'', component:HomeComponent},  
  {path:'app-details/:appid', component:ApplicantDetailsComponent},
  {path:'home', component:LogoutComponent},
  {path:'logout', component:LogoutComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
 