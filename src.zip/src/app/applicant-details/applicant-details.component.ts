import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApplicantDetailsService } from '../applicant-details.service';
import { ApplicantDetails } from '../ApplicantDetails';


@Component({
  selector: 'app-applicant-details',
  templateUrl: './applicant-details.component.html',
  styleUrls: ['./applicant-details.component.css']
})
export class ApplicantDetailsComponent implements OnInit {
 
  applicantDetails: ApplicantDetails= new ApplicantDetails();
 
   constructor(private ads: ApplicantDetailsService) { }
   ngOnInit(): void {
     this.ads.loadApplicantDetailsByIdService(20220001).subscribe(
    (data) => {
      this.applicantDetails = data;
    },
    (err) => {
      console.log(err);
    }
); }

  // anyNumber: number=20220001;
  
  // loadSingleUserDetails(x : number) {
  //   this.ads.loadApplicantDetailsByIdService(x).subscribe(
  //       (data) => {
  //         this.applicantDetails = data;
  //       },
  //       (err) => {
  //         console.log(err);
  //       }
  //   );
  }

    // authenticate(){
    //   this.router.navigate(['/logout']);
    // }


   // goToAddDetails(){
  //   this.router.navigate(['/add-details']);
  // }
  // goToHome(){
  //   this.router.navigate(['/home']);
  // }
  // logout(){
  //   this.router.navigate(['/logout']);
  // }

