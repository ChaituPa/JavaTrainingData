import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PendingApplComponent } from './pending-appl.component';

describe('PendingApplComponent', () => {
  let component: PendingApplComponent;
  let fixture: ComponentFixture<PendingApplComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PendingApplComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PendingApplComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
